// REIS Cars - Mobile-First Premium Car Rental App

// Application Data with Real Car Images
const appData = {
  vehicles: [
    // Luxury Vehicles
    {
      id: 1,
      make: "BMW",
      model: "5 Series",
      year: 2024,
      type: "Luxury Sedan",
      category: "luxury",
      fuelType: "Petrol",
      transmission: "Automatic",
      seats: 5,
      available: true,
      status: "Available",
      location: "Mumbai",
      features: ["Premium Audio", "Leather Seats", "Sunroof", "GPS", "Climate Control"],
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 15000
    },
    {
      id: 2,
      make: "Mercedes",
      model: "S-Class",
      year: 2024,
      type: "Ultra Luxury",
      category: "luxury",
      fuelType: "Petrol",
      transmission: "Automatic",
      seats: 5,
      available: true,
      status: "Available",
      location: "Delhi",
      features: ["Maybach Interior", "Burmester Audio", "Executive Rear Seats", "Magic Body Control"],
      rating: 5.0,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756896775/pplx_project_search_images/52f54ee322880e87106913a53642c3d937b6466f.png",
      pricePerDay: 30000
    },
    {
      id: 3,
      make: "Audi",
      model: "A6",
      year: 2024,
      type: "Luxury Sedan",
      category: "luxury",
      fuelType: "Diesel",
      transmission: "Automatic",
      seats: 5,
      available: false,
      status: "On Trip",
      location: "Bangalore",
      features: ["Virtual Cockpit", "Quattro AWD", "Bang & Olufsen Audio", "Matrix LED"],
      rating: 4.7,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756525221/pplx_project_search_images/d126186863fdd59b58a9b36fba2f912318c7c922.png",
      pricePerDay: 16000
    },
    {
      id: 4,
      make: "Porsche",
      model: "Panamera",
      year: 2023,
      type: "Luxury Sports",
      category: "luxury",
      fuelType: "Petrol",
      transmission: "Automatic",
      seats: 4,
      available: true,
      status: "Available",
      location: "Mumbai",
      features: ["Sport Chrono", "Bose Audio", "Adaptive Suspension", "Carbon Fiber"],
      rating: 4.9,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756896733/pplx_project_search_images/92f745e9bbb33200c012d2a623ccceb91ec68d5b.png",
      pricePerDay: 25000
    },
    {
      id: 5,
      make: "BMW",
      model: "X5",
      year: 2024,
      type: "Luxury SUV",
      category: "luxury",
      fuelType: "Diesel",
      transmission: "Automatic",
      seats: 7,
      available: true,
      status: "Available",
      location: "Pune",
      features: ["xDrive AWD", "Harman Kardon Audio", "Gesture Control", "Air Suspension"],
      rating: 4.8,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756896776/pplx_project_search_images/eff4df45894b57f1030fbb24ebf4b8008fb1aa6b.png",
      pricePerDay: 17000
    },
    // Premium Vehicles
    {
      id: 6,
      make: "Toyota",
      model: "Land Cruiser",
      year: 2024,
      type: "Premium SUV",
      category: "premium",
      fuelType: "Diesel",
      transmission: "Automatic",
      seats: 8,
      available: true,
      status: "Available",
      location: "Chennai",
      features: ["4WD System", "Premium Leather", "Multi-zone AC", "Safety Sense"],
      rating: 4.5,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756041278/pplx_project_search_images/cd988431565a44ad92e956fe301e53af70cac996.png",
      pricePerDay: 12000
    },
    {
      id: 7,
      make: "Kia",
      model: "Carnival",
      year: 2024,
      type: "Premium MPV",
      category: "premium",
      fuelType: "Diesel",
      transmission: "Automatic",
      seats: 8,
      available: true,
      status: "Available",
      location: "Hyderabad",
      features: ["Captain Seats", "Dual Sunroof", "Premium Audio", "360 Camera"],
      rating: 4.4,
      image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 8000
    },
    // Regular Vehicles - Suzuki Models
    {
      id: 8,
      make: "Suzuki",
      model: "Swift",
      year: 2024,
      type: "Hatchback",
      category: "regular",
      fuelType: "Petrol",
      transmission: "Manual",
      seats: 5,
      available: true,
      status: "Available",
      location: "Mumbai",
      features: ["Touchscreen", "Keyless Entry", "Dual Airbags", "ABS"],
      rating: 4.0,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756896733/pplx_project_search_images/00fa77f64e9238e591a690fa7d13f994bb083213.png",
      pricePerDay: 2000
    },
    {
      id: 9,
      make: "Suzuki",
      model: "Baleno",
      year: 2024,
      type: "Hatchback",
      category: "regular",
      fuelType: "Petrol",
      transmission: "CVT",
      seats: 5,
      available: false,
      status: "Under Maintenance",
      location: "Pune",
      features: ["SmartPlay Infotainment", "Auto AC", "Push Start", "Cruise Control"],
      rating: 4.1,
      image: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 2500
    },
    {
      id: 10,
      make: "Suzuki",
      model: "Ertiga",
      year: 2024,
      type: "MPV",
      category: "regular",
      fuelType: "Petrol",
      transmission: "Manual",
      seats: 7,
      available: true,
      status: "Available",
      location: "Bangalore",
      features: ["7-Seater", "Spacious Interior", "Touchscreen", "Rear AC Vents"],
      rating: 4.0,
      image: "https://pplx-res.cloudinary.com/image/upload/v1756896750/pplx_project_search_images/3b678e292a10705bd8f250de74f6357219f4dc78.png",
      pricePerDay: 3000
    },
    // Hyundai Models
    {
      id: 11,
      make: "Hyundai",
      model: "Verna",
      year: 2024,
      type: "Sedan",
      category: "regular",
      fuelType: "Petrol",
      transmission: "Manual",
      seats: 5,
      available: true,
      status: "Available",
      location: "Delhi",
      features: ["Touchscreen", "Automatic Climate Control", "Rear AC Vents", "Wireless Charging"],
      rating: 4.2,
      image: "https://images.unsplash.com/photo-1493238792000-8113da705763?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 3500
    },
    {
      id: 12,
      make: "Hyundai",
      model: "Creta",
      year: 2024,
      type: "SUV",
      category: "regular",
      fuelType: "Diesel",
      transmission: "Automatic",
      seats: 5,
      available: true,
      status: "Available",
      location: "Gurgaon",
      features: ["Sunroof", "Touchscreen", "Wireless Charging", "360 Camera"],
      rating: 4.3,
      image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 4500
    },
    // More Kia Models
    {
      id: 13,
      make: "Kia",
      model: "Seltos",
      year: 2024,
      type: "SUV",
      category: "regular",
      fuelType: "Petrol",
      transmission: "Automatic",
      seats: 5,
      available: false,
      status: "Reserved",
      location: "Noida",
      features: ["UVO Connect", "LED Headlamps", "Ventilated Seats", "Bose Audio"],
      rating: 4.4,
      image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 4000
    },
    {
      id: 14,
      make: "Kia",
      model: "Sonet",
      year: 2024,
      type: "Compact SUV",
      category: "regular",
      fuelType: "Petrol",
      transmission: "Manual",
      seats: 5,
      available: true,
      status: "Available",
      location: "Chennai",
      features: ["Compact Design", "Fuel Efficient", "Modern Interior", "Safety Features"],
      rating: 4.1,
      image: "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=400&h=250&fit=crop&crop=center",
      pricePerDay: 2800
    }
  ],
  
  bookings: [
    {
      id: 1,
      userId: 1,
      vehicleId: 1,
      startDate: "2025-09-10",
      endDate: "2025-09-12",
      totalCost: 30000,
      status: "completed",
      pickupLocation: "Mumbai Airport",
      dropLocation: "Pune"
    },
    {
      id: 2,
      userId: 1,
      vehicleId: 5,
      startDate: "2025-09-15",
      endDate: "2025-09-18",
      totalCost: 51000,
      status: "active",
      pickupLocation: "Pune",
      dropLocation: "Goa"
    },
    {
      id: 3,
      userId: 1,
      vehicleId: 2,
      startDate: "2025-09-20",
      endDate: "2025-09-22",
      totalCost: 60000,
      status: "upcoming",
      pickupLocation: "Mumbai",
      dropLocation: "Udaipur"
    }
  ],

  user: {
    id: 1,
    name: "Rajesh Kumar",
    email: "rajesh@email.com",
    phone: "+91 9876543210",
    totalBookings: 12,
    loyaltyPoints: 1500,
    profileImage: "https://via.placeholder.com/80x80?text=RK"
  }
};

// App State
let currentRole = null;
let selectedCar = null;
let currentFilters = {
  category: 'all',
  location: [],
  brand: [],
  priceRange: null
};

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
  console.log('🚗 REIS Cars App Initializing...');
  initializeApp();
});

function initializeApp() {
  // Show splash screen for 3 seconds
  setTimeout(() => {
    hideSplashScreen();
    showLandingPage();
  }, 3000);

  setupEventListeners();
  setupTouchInteractions();
  console.log('✅ REIS Cars App Ready');
}

function hideSplashScreen() {
  const splash = document.getElementById('splashScreen');
  if (splash) {
    splash.style.display = 'none';
  }
}

function showLandingPage() {
  hideAllPages();
  const landing = document.getElementById('landingPage');
  if (landing) {
    landing.classList.remove('hidden');
  }
  updateHeader('REIS Cars', false, false);
}

function hideAllPages() {
  const pages = document.querySelectorAll('.page-content, .app-container');
  pages.forEach(page => page.classList.add('hidden'));
}

function updateHeader(title, showBack = false, showProfile = false) {
  const headerTitle = document.getElementById('headerTitle');
  const backBtn = document.getElementById('backBtn');
  const profileBtn = document.getElementById('profileBtn');

  if (headerTitle) headerTitle.textContent = title;
  if (backBtn) backBtn.style.display = showBack ? 'flex' : 'none';
  if (profileBtn) profileBtn.style.display = showProfile ? 'flex' : 'none';
}

// Role Selection - Fixed
function selectRole(role) {
  console.log('📱 Selected role:', role);
  currentRole = role;

  // Add small delay for visual feedback
  setTimeout(() => {
    if (role === 'customer') {
      showCustomerApp();
    } else if (role === 'admin') {
      showAdminApp();
    } else {
      // For other roles, show customer app for demo
      showCustomerApp();
    }
  }, 200);
}

function showCustomerApp() {
  hideAllPages();
  const customerApp = document.getElementById('customerApp');
  if (customerApp) {
    customerApp.classList.remove('hidden');
  }
  
  updateHeader('REIS Cars', false, true);
  loadHomeTab();
  showFAB();
  
  // Ensure home tab is active
  switchTab('home');
}

function showAdminApp() {
  hideAllPages();
  const adminApp = document.getElementById('adminApp');
  if (adminApp) {
    adminApp.classList.remove('hidden');
  }
  
  updateHeader('Admin Dashboard', true, false);
  
  // Initialize admin chart with delay
  setTimeout(() => {
    initializeAdminChart();
  }, 100);
}

// Navigation Handling - Fixed
function setupEventListeners() {
  // Bottom navigation - Fixed click handlers
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const tab = item.dataset.tab;
      console.log('Nav clicked:', tab);
      switchTab(tab);
    });
  });

  // Category chips
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('category-chip')) {
      const category = e.target.dataset.category;
      selectCategory(category);
    }
  });

  // Booking tabs
  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('booking-tab-btn')) {
      const status = e.target.dataset.status;
      selectBookingStatus(status);
    }
  });

  // Forms
  const bookingForm = document.getElementById('bookingForm');
  if (bookingForm) {
    bookingForm.addEventListener('submit', handleBooking);
  }

  // Search input
  const searchInput = document.querySelector('.search-input');
  if (searchInput) {
    searchInput.addEventListener('input', handleSearch);
  }

  // Modal close handlers - Fixed
  document.addEventListener('click', (e) => {
    // Close modal when clicking outside
    if (e.target.classList.contains('modal')) {
      const modalId = e.target.id;
      closeModal(modalId);
    }
    
    // Close button clicks
    if (e.target.classList.contains('modal-close')) {
      const modal = e.target.closest('.modal');
      if (modal) {
        closeModal(modal.id);
      }
    }
  });

  // Escape key to close modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const openModal = document.querySelector('.modal:not(.hidden)');
      if (openModal) {
        closeModal(openModal.id);
      }
    }
  });

  // Date input change handlers
  document.addEventListener('change', function(e) {
    if (e.target.name === 'startDate' || e.target.name === 'endDate') {
      updatePricing();
    }
  });
}

function setupTouchInteractions() {
  // Add touch feedback to interactive elements
  const touchElements = document.querySelectorAll('.role-card, .car-card, .nav-item, .menu-item, .booking-card');
  
  touchElements.forEach(element => {
    element.addEventListener('touchstart', () => {
      element.style.transform = 'scale(0.98)';
    });
    
    element.addEventListener('touchend', () => {
      setTimeout(() => {
        element.style.transform = '';
      }, 150);
    });
  });

  // Pull to refresh simulation
  let startY = 0;
  let currentY = 0;
  let isRefreshing = false;

  document.addEventListener('touchstart', (e) => {
    startY = e.touches[0].clientY;
  });

  document.addEventListener('touchmove', (e) => {
    if (window.scrollY === 0 && !isRefreshing) {
      currentY = e.touches[0].clientY;
      const pullDistance = currentY - startY;

      if (pullDistance > 100) {
        // Trigger refresh
        isRefreshing = true;
        refreshContent();
      }
    }
  });
}

function refreshContent() {
  console.log('🔄 Refreshing content...');
  
  // Show loading state
  const activeTab = document.querySelector('.tab-content:not(.hidden)');
  if (activeTab) {
    activeTab.classList.add('loading');
  }

  // Simulate refresh delay
  setTimeout(() => {
    if (activeTab) {
      activeTab.classList.remove('loading');
    }
    
    // Reload current tab data
    const currentTab = getCurrentTab();
    if (currentTab === 'home') {
      loadHomeTab();
    } else if (currentTab === 'cars') {
      loadCarsTab();
    } else if (currentTab === 'bookings') {
      loadBookingsTab();
    }
    
    isRefreshing = false;
    console.log('✅ Content refreshed');
  }, 1000);
}

function getCurrentTab() {
  const activeNav = document.querySelector('.nav-item.active');
  return activeNav ? activeNav.dataset.tab : 'home';
}

// Tab Management - Fixed
function switchTab(tabName) {
  console.log('Switching to tab:', tabName);
  
  // Update navigation
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.classList.toggle('active', item.dataset.tab === tabName);
  });

  // Switch tab content
  const tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(content => {
    content.classList.add('hidden');
  });

  const activeTab = document.getElementById(tabName + 'Tab');
  if (activeTab) {
    activeTab.classList.remove('hidden');
    console.log('Activated tab:', tabName + 'Tab');
  }

  // Load tab content
  switch (tabName) {
    case 'home':
      loadHomeTab();
      break;
    case 'cars':
      loadCarsTab();
      break;
    case 'bookings':
      loadBookingsTab();
      break;
    case 'profile':
      loadProfileTab();
      break;
    case 'more':
      loadMoreTab();
      break;
  }

  // Update header
  const tabTitles = {
    home: 'REIS Cars',
    cars: 'Browse Cars',
    bookings: 'My Bookings',
    profile: 'Profile',
    more: 'More'
  };

  updateHeader(tabTitles[tabName] || 'REIS Cars', false, tabName !== 'profile');
}

// Content Loading Functions
function loadHomeTab() {
  console.log('Loading home tab...');
  loadCarsGrid();
}

function loadCarsTab() {
  console.log('Loading cars tab...');
  loadCarsList();
}

function loadBookingsTab() {
  console.log('Loading bookings tab...');
  loadBookingsList('active');
}

function loadProfileTab() {
  console.log('Loading profile tab...');
  const user = appData.user;
  const profileName = document.getElementById('profileName');
  const profileEmail = document.getElementById('profileEmail');
  const totalBookings = document.getElementById('totalBookings');
  const loyaltyPoints = document.getElementById('loyaltyPoints');
  const profileImage = document.getElementById('profileImage');
  
  if (profileName) profileName.textContent = user.name;
  if (profileEmail) profileEmail.textContent = user.email;
  if (totalBookings) totalBookings.textContent = user.totalBookings;
  if (loyaltyPoints) loyaltyPoints.textContent = user.loyaltyPoints;
  if (profileImage) profileImage.src = user.profileImage;
}

function loadMoreTab() {
  console.log('Loading more tab...');
  // More tab is static content
}

// Car Display Functions
function loadCarsGrid() {
  const container = document.getElementById('carsGrid');
  if (!container) return;

  const filteredCars = getFilteredCars();
  
  container.innerHTML = filteredCars.map(car => `
    <div class="car-card" onclick="showCarDetail(${car.id})">
      <div class="car-image">
        <img src="${car.image}" alt="${car.make} ${car.model}" onerror="this.style.display='none'; this.parentNode.innerHTML='🚗 ${car.make} ${car.model}';">
        <div class="car-badge">${car.category.toUpperCase()}</div>
        <div class="availability-badge ${car.available ? 'available' : 'unavailable'}">
          ${car.status}
        </div>
      </div>
      <div class="car-info">
        <div class="car-title">${car.make} ${car.model} ${car.year}</div>
        <div class="car-details">
          <span>${car.seats} Seats</span>
          <span>${car.fuelType}</span>
        </div>
        <div class="car-location">📍 ${car.location}</div>
        <div class="car-features">
          ${car.features.slice(0, 3).map(feature => `
            <span class="feature-tag">${feature}</span>
          `).join('')}
        </div>
        <div class="car-footer">
          <div class="car-rating">⭐ ${car.rating}</div>
          <button class="book-btn" onclick="event.stopPropagation(); openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
            ${car.available ? 'Book Now' : car.status}
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function loadCarsList() {
  const container = document.getElementById('carsList');
  if (!container) return;

  const filteredCars = getFilteredCars();
  
  container.innerHTML = filteredCars.map(car => `
    <div class="car-card" onclick="showCarDetail(${car.id})">
      <div class="car-image">
        <img src="${car.image}" alt="${car.make} ${car.model}" onerror="this.style.display='none'; this.parentNode.innerHTML='🚗 ${car.make} ${car.model}';">
        <div class="availability-badge ${car.available ? 'available' : 'unavailable'}">
          ${car.status}
        </div>
      </div>
      <div class="car-info">
        <div class="car-title">${car.make} ${car.model} ${car.year}</div>
        <div class="car-details">
          <span>${car.type}</span>
          <span>${car.transmission}</span>
        </div>
        <div class="car-location">📍 ${car.location}</div>
        <div class="car-features">
          ${car.features.slice(0, 2).map(feature => `
            <span class="feature-tag">${feature}</span>
          `).join('')}
        </div>
        <div class="car-footer">
          <div class="car-rating">⭐ ${car.rating}</div>
          <button class="book-btn" onclick="event.stopPropagation(); openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
            Book Now
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function getFilteredCars() {
  let cars = appData.vehicles;

  // Filter by category
  if (currentFilters.category !== 'all') {
    cars = cars.filter(car => car.category === currentFilters.category);
  }

  // Filter by location
  if (currentFilters.location.length > 0) {
    cars = cars.filter(car => currentFilters.location.includes(car.location));
  }

  // Filter by brand
  if (currentFilters.brand.length > 0) {
    cars = cars.filter(car => currentFilters.brand.includes(car.make));
  }

  return cars;
}

function selectCategory(category) {
  currentFilters.category = category;

  // Update UI
  const chips = document.querySelectorAll('.category-chip');
  chips.forEach(chip => {
    chip.classList.toggle('active', chip.dataset.category === category);
  });

  // Reload content
  loadCarsGrid();
}

// Booking Functions
function loadBookingsList(status = 'active') {
  const container = document.getElementById('bookingsList');
  if (!container) return;

  // Update tabs
  const tabs = document.querySelectorAll('.booking-tab-btn');
  tabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.status === status);
  });

  const filteredBookings = appData.bookings.filter(booking => booking.status === status);

  if (filteredBookings.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div style="text-align: center; padding: 2rem; color: var(--color-text-secondary);">
          <div style="font-size: 3rem; margin-bottom: 1rem;">📅</div>
          <h3>No ${status} bookings</h3>
          <p>Your ${status} bookings will appear here</p>
        </div>
      </div>
    `;
    return;
  }

  container.innerHTML = filteredBookings.map(booking => {
    const car = appData.vehicles.find(v => v.id === booking.vehicleId);
    return `
      <div class="booking-card" onclick="showBookingDetail(${booking.id})">
        <div class="booking-header">
          <div class="booking-id">Booking #${booking.id}</div>
          <div class="booking-status ${status}">${status.toUpperCase()}</div>
        </div>
        <div class="booking-details">
          <div>
            <div class="booking-detail-label">Vehicle</div>
            <div class="booking-detail-value">${car ? car.make + ' ' + car.model : 'N/A'}</div>
          </div>
          <div>
            <div class="booking-detail-label">Dates</div>
            <div class="booking-detail-value">${booking.startDate} to ${booking.endDate}</div>
          </div>
          <div>
            <div class="booking-detail-label">Pickup</div>
            <div class="booking-detail-value">${booking.pickupLocation}</div>
          </div>
          <div>
            <div class="booking-detail-label">Total</div>
            <div class="booking-detail-value">₹${booking.totalCost.toLocaleString()}</div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function selectBookingStatus(status) {
  loadBookingsList(status);
}

// Modal Functions - Fixed
function showCarDetail(carId) {
  console.log('Showing car detail for:', carId);
  const car = appData.vehicles.find(c => c.id === carId);
  if (!car) return;

  const modal = document.getElementById('carDetailModal');
  const content = document.getElementById('carDetailContent');
  
  content.innerHTML = `
    <div class="car-detail-header">
      <img src="${car.image}" alt="${car.make} ${car.model}" class="car-detail-image" onerror="this.style.display='none';">
    </div>
    <div class="car-detail-info">
      <h2>${car.make} ${car.model} ${car.year}</h2>
      <div style="display: flex; gap: 1rem; margin-bottom: 1rem;">
        <span class="availability-badge ${car.available ? 'available' : 'unavailable'}">
          ${car.status}
        </span>
        <span class="car-badge">${car.category.toUpperCase()}</span>
      </div>
      
      <div class="car-specs" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
        <div>
          <div style="color: var(--color-text-secondary); font-size: 0.875rem;">Type</div>
          <div style="font-weight: 500;">${car.type}</div>
        </div>
        <div>
          <div style="color: var(--color-text-secondary); font-size: 0.875rem;">Seats</div>
          <div style="font-weight: 500;">${car.seats}</div>
        </div>
        <div>
          <div style="color: var(--color-text-secondary); font-size: 0.875rem;">Fuel</div>
          <div style="font-weight: 500;">${car.fuelType}</div>
        </div>
        <div>
          <div style="color: var(--color-text-secondary); font-size: 0.875rem;">Transmission</div>
          <div style="font-weight: 500;">${car.transmission}</div>
        </div>
      </div>

      <div class="car-location" style="margin-bottom: 1.5rem;">
        <div style="color: var(--color-text-secondary); font-size: 0.875rem; margin-bottom: 0.5rem;">Location</div>
        <div style="font-weight: 500;">📍 ${car.location}</div>
      </div>

      <div class="car-features" style="margin-bottom: 1.5rem;">
        <div style="color: var(--color-text-secondary); font-size: 0.875rem; margin-bottom: 0.75rem;">Features</div>
        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
          ${car.features.map(feature => `<span class="feature-tag">${feature}</span>`).join('')}
        </div>
      </div>

      <div class="pricing-info" style="background: var(--color-bg-1); padding: 1.25rem; border-radius: 12px; margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="color: var(--color-text-secondary); font-size: 0.875rem;">Starting from</div>
            <div style="font-size: 1.5rem; font-weight: 700; color: var(--color-primary);">₹${car.pricePerDay.toLocaleString()}</div>
            <div style="color: var(--color-text-secondary); font-size: 0.875rem;">per day</div>
          </div>
          <div style="text-align: center;">
            <div style="display: flex; align-items: center; gap: 0.25rem; margin-bottom: 0.25rem;">
              <span style="color: #FFD700;">⭐</span>
              <span style="font-weight: 600;">${car.rating}</span>
            </div>
            <div style="color: var(--color-text-secondary); font-size: 0.75rem;">Rating</div>
          </div>
        </div>
      </div>

      <button class="btn btn-primary btn-full" onclick="closeModal('carDetailModal'); openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
        ${car.available ? 'Book Now' : car.status}
      </button>
    </div>
  `;

  modal.classList.remove('hidden');
}

function openBookingModal(carId) {
  console.log('Opening booking modal for car:', carId);
  const car = appData.vehicles.find(c => c.id === carId);
  if (!car || !car.available) {
    alert(`This ${car ? car.make + ' ' + car.model : 'vehicle'} is currently ${car ? car.status.toLowerCase() : 'unavailable'}. Please select another vehicle.`);
    return;
  }

  selectedCar = car;
  const modal = document.getElementById('bookingModal');
  const carInfo = document.getElementById('selectedCarInfo');
  
  carInfo.innerHTML = `
    <div style="display: flex; gap: 1rem; padding: 1rem; background: var(--color-bg-2); border-radius: 12px; margin-bottom: 1.5rem;">
      <img src="${car.image}" alt="${car.make} ${car.model}" style="width: 80px; height: 60px; object-fit: cover; border-radius: 8px;" onerror="this.style.display='none';">
      <div>
        <div style="font-weight: 600; margin-bottom: 0.25rem;">${car.make} ${car.model} ${car.year}</div>
        <div style="color: var(--color-text-secondary); font-size: 0.875rem;">${car.type} • ${car.seats} Seats</div>
        <div style="color: var(--color-success); font-size: 0.875rem; margin-top: 0.25rem;">✓ Available at ${car.location}</div>
      </div>
    </div>
  `;

  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  const startDateInput = document.querySelector('input[name="startDate"]');
  const endDateInput = document.querySelector('input[name="endDate"]');
  
  if (startDateInput) startDateInput.min = today;
  if (endDateInput) endDateInput.min = today;

  updatePricing();
  modal.classList.remove('hidden');
}

function updatePricing() {
  if (!selectedCar) return;

  const basePrice = selectedCar.pricePerDay;
  const startDateInput = document.querySelector('input[name="startDate"]');
  const endDateInput = document.querySelector('input[name="endDate"]');
  
  if (!startDateInput || !endDateInput) return;
  
  const startDate = startDateInput.value;
  const endDate = endDateInput.value;

  let days = 1;
  if (startDate && endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) || 1;
  }

  const totalCost = basePrice * days;

  const basePriceElement = document.getElementById('basePrice');
  const totalCostElement = document.getElementById('totalCost');
  
  if (basePriceElement) basePriceElement.textContent = `₹${basePrice.toLocaleString()}`;
  if (totalCostElement) totalCostElement.textContent = `₹${totalCost.toLocaleString()}`;
}

function handleBooking(e) {
  e.preventDefault();
  console.log('Handling booking submission...');
  
  const formData = new FormData(e.target);
  const startDate = formData.get('startDate');
  const endDate = formData.get('endDate');
  const pickupLocation = formData.get('pickupLocation');

  if (!startDate || !endDate || !pickupLocation) {
    alert('Please fill all required fields');
    return;
  }

  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) || 1;
  const totalCost = selectedCar.pricePerDay * days;

  const newBooking = {
    id: Date.now(),
    userId: appData.user.id,
    vehicleId: selectedCar.id,
    startDate,
    endDate,
    pickupLocation,
    totalCost,
    status: 'upcoming'
  };

  // Add booking to data
  appData.bookings.push(newBooking);
  
  // Update car status
  selectedCar.available = false;
  selectedCar.status = 'Reserved';

  // Update user stats
  appData.user.totalBookings++;
  appData.user.loyaltyPoints += Math.floor(totalCost / 100);

  // Close modal and show success
  closeModal('bookingModal');
  
  // Show success message
  showSuccessMessage(`Booking confirmed! 
    🚗 ${selectedCar.make} ${selectedCar.model}
    📅 ${startDate} to ${endDate}
    💰 Total: ₹${totalCost.toLocaleString()}`);

  // Refresh displays
  loadCarsGrid();
  loadCarsList();
  
  // Switch to bookings tab
  setTimeout(() => {
    switchTab('bookings');
  }, 2000);
}

function showSuccessMessage(message) {
  const messageDiv = document.createElement('div');
  messageDiv.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: var(--color-success);
    color: white;
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
    z-index: 10000;
    max-width: 90%;
    box-shadow: var(--shadow-lg);
  `;
  messageDiv.innerHTML = message.replace(/\n/g, '<br>');
  
  document.body.appendChild(messageDiv);
  
  setTimeout(() => {
    messageDiv.remove();
  }, 3000);
}

// Search and Filter Functions
function handleSearch(e) {
  const query = e.target.value.toLowerCase();
  
  // Filter cars based on search query
  const allCars = appData.vehicles;
  const filteredCars = allCars.filter(car => 
    car.make.toLowerCase().includes(query) ||
    car.model.toLowerCase().includes(query) ||
    car.type.toLowerCase().includes(query) ||
    car.location.toLowerCase().includes(query)
  );

  // Update display with filtered results
  const container = document.getElementById('carsGrid') || document.getElementById('carsList');
  if (!container) return;

  if (filteredCars.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="text-align: center; padding: 2rem; color: var(--color-text-secondary);">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
        <h3>No cars found</h3>
        <p>Try adjusting your search terms</p>
      </div>
    `;
  } else {
    // Re-render with filtered cars
    const isGridView = container.id === 'carsGrid';
    if (isGridView) {
      renderCarsGrid(filteredCars, container);
    } else {
      renderCarsList(filteredCars, container);
    }
  }
}

function renderCarsGrid(cars, container) {
  container.innerHTML = cars.map(car => `
    <div class="car-card" onclick="showCarDetail(${car.id})">
      <div class="car-image">
        <img src="${car.image}" alt="${car.make} ${car.model}" onerror="this.style.display='none'; this.parentNode.innerHTML='🚗 ${car.make} ${car.model}';">
        <div class="car-badge">${car.category.toUpperCase()}</div>
        <div class="availability-badge ${car.available ? 'available' : 'unavailable'}">
          ${car.status}
        </div>
      </div>
      <div class="car-info">
        <div class="car-title">${car.make} ${car.model} ${car.year}</div>
        <div class="car-details">
          <span>${car.seats} Seats</span>
          <span>${car.fuelType}</span>
        </div>
        <div class="car-location">📍 ${car.location}</div>
        <div class="car-features">
          ${car.features.slice(0, 3).map(feature => `
            <span class="feature-tag">${feature}</span>
          `).join('')}
        </div>
        <div class="car-footer">
          <div class="car-rating">⭐ ${car.rating}</div>
          <button class="book-btn" onclick="event.stopPropagation(); openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
            ${car.available ? 'Book Now' : car.status}
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function renderCarsList(cars, container) {
  container.innerHTML = cars.map(car => `
    <div class="car-card" onclick="showCarDetail(${car.id})">
      <div class="car-image">
        <img src="${car.image}" alt="${car.make} ${car.model}" onerror="this.style.display='none'; this.parentNode.innerHTML='🚗 ${car.make} ${car.model}';">
        <div class="availability-badge ${car.available ? 'available' : 'unavailable'}">
          ${car.status}
        </div>
      </div>
      <div class="car-info">
        <div class="car-title">${car.make} ${car.model} ${car.year}</div>
        <div class="car-details">
          <span>${car.type}</span>
          <span>${car.transmission}</span>
        </div>
        <div class="car-location">📍 ${car.location}</div>
        <div class="car-features">
          ${car.features.slice(0, 2).map(feature => `
            <span class="feature-tag">${feature}</span>
          `).join('')}
        </div>
        <div class="car-footer">
          <div class="car-rating">⭐ ${car.rating}</div>
          <button class="book-btn" onclick="event.stopPropagation(); openBookingModal(${car.id})" ${!car.available ? 'disabled' : ''}>
            Book Now
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function showFilters() {
  const modal = document.getElementById('filterModal');
  if (modal) {
    modal.classList.remove('hidden');
  }
}

function clearFilters() {
  currentFilters = {
    category: 'all',
    location: [],
    brand: [],
    priceRange: null
  };
  
  // Clear checkboxes
  const checkboxes = document.querySelectorAll('#filterModal input[type="checkbox"]');
  checkboxes.forEach(cb => cb.checked = false);
  
  closeModal('filterModal');
  loadCarsGrid();
  loadCarsList();
}

function applyFilters() {
  // Get selected filters
  const locationChecks = document.querySelectorAll('#filterModal input[value="Mumbai"], #filterModal input[value="Delhi"], #filterModal input[value="Bangalore"]');
  const brandChecks = document.querySelectorAll('#filterModal input[value="BMW"], #filterModal input[value="Mercedes"], #filterModal input[value="Suzuki"], #filterModal input[value="Hyundai"], #filterModal input[value="Kia"]');
  
  currentFilters.location = Array.from(locationChecks).filter(cb => cb.checked).map(cb => cb.value);
  currentFilters.brand = Array.from(brandChecks).filter(cb => cb.checked).map(cb => cb.value);
  
  closeModal('filterModal');
  loadCarsGrid();
  loadCarsList();
}

// Admin Functions
function initializeAdminChart() {
  const canvas = document.getElementById('adminChart');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
      datasets: [{
        label: 'Revenue (₹L)',
        data: [25, 28, 32, 29, 35, 42, 38, 45, 48],
        backgroundColor: '#1FB8CD',
        borderColor: '#1FB8CD',
        borderWidth: 3,
        fill: false,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return '₹' + value + 'L';
            }
          }
        }
      }
    }
  });
}

// Utility Functions - Fixed
function closeModal(modalId) {
  console.log('Closing modal:', modalId);
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('hidden');
  }
}

function goBack() {
  if (currentRole) {
    // Go back to customer app
    showCustomerApp();
  } else {
    // Go back to landing
    showLandingPage();
  }
}

function showProfile() {
  switchTab('profile');
}

function logout() {
  currentRole = null;
  selectedCar = null;
  currentFilters = {
    category: 'all',
    location: [],
    brand: [],
    priceRange: null
  };
  
  hideFAB();
  showLandingPage();
}

function showFAB() {
  const fab = document.querySelector('.fab');
  if (fab) {
    fab.style.display = 'flex';
  }
}

function hideFAB() {
  const fab = document.querySelector('.fab');
  if (fab) {
    fab.style.display = 'none';
  }
}

function quickBook() {
  // Show available cars for quick booking
  switchTab('cars');
}

function showBookingDetail(bookingId) {
  console.log('Show booking detail:', bookingId);
  // Implementation for booking detail view
}

// Make functions globally available
window.selectRole = selectRole;
window.switchTab = switchTab;
window.showCarDetail = showCarDetail;
window.openBookingModal = openBookingModal;
window.closeModal = closeModal;
window.goBack = goBack;
window.showProfile = showProfile;
window.logout = logout;
window.showFilters = showFilters;
window.clearFilters = clearFilters;
window.applyFilters = applyFilters;
window.quickBook = quickBook;
window.showBookingDetail = showBookingDetail;

console.log('🚗 REIS Cars App JavaScript Loaded Successfully!');